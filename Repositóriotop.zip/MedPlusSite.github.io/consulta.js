const mysql = require('mysql2');
//const bcrypt = require('bcrypt');//

// Configurar a conexão com o banco de dados MySQL
const db = mysql.createConnection({
  host: 'localhost',
  user: 'phpmyadmin',
  password: 'isabila',
  database: 'medical',
});

async function marcarConsulta(nomepaciente, nomemedico, horario, dataconsulta) {
  try {
    // Verificar se o horário já está ocupado
    const [existingAppointments] = await db.promise().query('SELECT * FROM consultas WHERE dataconsulta = ? AND horario = ?', [dataconsulta, horario]);

    if (existingAppointments.length > 0) {
      throw new Error('Este horário já está ocupado!');
    }

    // Inserir a nova consulta no banco de dados
    const [result] = await db.promise().query('INSERT INTO consultas (nomepaciente, nomemedico, horario, dataconsulta) VALUES (?,?,?,?)', [nomepaciente, nomemedico, horario, dataconsulta]);

    if (result.insertId) {
      return result.insertId;
    } else {
      throw new Error('Erro ao marcar a consulta.');
    }
  } catch (error) {
    throw error;
  }
}

module.exports = {
  marcarConsulta,
};

