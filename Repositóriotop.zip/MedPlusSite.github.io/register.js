const mysql = require('mysql2');
//const bcrypt = require('bcrypt');//

// Configurar a conexão com o banco de dados MySQL
const db = mysql.createConnection({
  host: 'localhost',
  user: 'phpmyadmin',
  password: 'isabila',
  database: 'medical',
});

// Função para cadastrar um novo usuário
async function registerUser(username,password) {
const { email, senha, nome, tipo } = req.body;
  try {
    // Verificar se o usuário já existe
    const [existingUsers] = await db.promise().query('SELECT * FROM usuarios WHERE email = ?', [email]);

    if (existingUsers.length > 0) {
      throw new Error('Conta já existe');
    }

    // Hash da senha usando bcrypt
   // const hashedPassword = await bcrypt.hash(password, 10);//

    // Inserir o novo usuário no banco de dados
    const [result] = await db.promise().query('INSERT INTO usuarios (email, senha, nome, tipo) VALUES (?, SHA1(?), ?, ?)', [email,senha,nome,tipo]);

    if (result.insertId) {
      return result.insertId;
    } else {
      throw new Error('Erro ao cadastrar o usuário.');
    }
  } catch (error) {
    throw error;
  }
}

module.exports = {
  registerUser,
};
